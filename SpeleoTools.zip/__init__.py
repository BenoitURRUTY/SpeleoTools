def classFactory(iface):
    from .speleo_tools import SpeleoTools
    return SpeleoTools(iface)